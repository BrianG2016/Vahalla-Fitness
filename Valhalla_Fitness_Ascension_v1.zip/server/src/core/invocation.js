export function invokeName(t,n){if(!n)return t;const has=new RegExp(`\\b${n}\\b`,'i').test(t);return has?t:`${n}, ${t}`}
