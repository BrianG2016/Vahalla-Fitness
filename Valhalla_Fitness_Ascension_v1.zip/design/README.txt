Design placeholders for banners, runes, and deity art.
