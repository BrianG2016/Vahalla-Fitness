/** @type {import('tailwindcss').Config} */
export default { content:['./index.html','./src/**/*.{js,jsx}'], theme:{ extend:{ colors:{ rune:'#d4af37', obsidian:'#0b0b0b', ember:'#8b0000' } } }, plugins:[] }
