export async function validateMovement(s){return {valid:true,reps:Math.floor(Math.random()*20)+10}}
