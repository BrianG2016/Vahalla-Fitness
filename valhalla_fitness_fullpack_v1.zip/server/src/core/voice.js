export async function speak(d,t){return {audioUrl:null, note:`TTS for ${d} pending`}}
